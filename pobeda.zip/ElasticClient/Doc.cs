namespace ElasticClient;

public class Doc
{
    public long Id { get; set; }
    public string Data { get; set; }
    public string Category { get; set; }
}